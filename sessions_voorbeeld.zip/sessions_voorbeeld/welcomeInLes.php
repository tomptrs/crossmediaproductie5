<?php

session_start();

if(isset($_SESSION["gebruiker"]))
{

	print "welkom " . $_SESSION["gebruiker"];
}
else
	header("location:loginInLes.php");
?>