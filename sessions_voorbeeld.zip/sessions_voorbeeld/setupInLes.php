<?php


//if (isset($_POST["txtuser"]) && isset($_POST["txtpassword"]))
//{
	
	require "db2.php";
	
	$db = new Databank2();
	$test = "select * from gebruikers";
	
	$db->query($test);
	
	while($line = $db->result->fetch_assoc()){
  	  echo $line['username'] . '<br />';
   
		}
	
	//while($line = $db->fetchArray())
	//{
	//	print $line["username"] . "<br>";
	//}
	
	/*
	if($_POST["txtuser"] == "tom"  && $_POST["txtpassword"] == "tom")
	{
		session_start();
		$_SESSION["gebruiker"]=$_POST["txtuser"];
		header("location:welcomeInLes.php");
	}
	else {
		print "fout paswoord of gebruikersnaam";
	}
	 
	 */

//}

//else {
	
//	header("location:loginInLes.php");
//}


?>