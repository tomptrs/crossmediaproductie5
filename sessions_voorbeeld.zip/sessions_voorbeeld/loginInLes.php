<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
	"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
		<title>loginInLes</title>

	</head>

	<body>
		
		<form action="setupInLes.php" method="post">
			
			username:<input type="text" name="txtuser"/>
			password:<input type="text" name="txtpassword"/>
			<input type="submit"/>
		</form>

	</body>
</html>
